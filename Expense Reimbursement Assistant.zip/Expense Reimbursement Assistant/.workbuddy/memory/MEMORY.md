# 青禾报销助手 — 项目长期笔记

## 项目定位
报销流程智能体 Demo：员工自助查制度 → 提交材料 → 报销流程 → 授权查本人单据状态；制度由行政专员维护，业务事实由财务专员核对。

## 技术栈与约定（用户已确认）
- **存储**：JSON 文件存储（`db.js` 提供统一 store 接口），未来可替换回 MongoDB。
- **前端**：原生 HTML/CSS/JS 单页应用，零构建依赖。
- **后端**：Node.js + Express + JWT + bcryptjs + multer。
- **目录**：`qinghe-demo/`（原始 madriq 项目保留在 `madriq-base/` 作参考）。

## 角色与权限
| 角色 | 标识 | 权限 |
| --- | --- | --- |
| 员工 | employee | 查制度、提交报销、查本人单据 |
| 行政专员 | admin_ops | 维护制度（增/改/失效） |
| 财务专员 | finance | 查全部单据、核对业务事实（通过/驳回） |

## 关键实现
- 数据模型：User / Policy（制度）/ Expense（单据），字段见 `db.js` 种子数据。
- 权限中间件：`middleware/auth.js` 的 `verifyToken` + `restrictTo`。
- 制度只查"有效"（status=active），管理员用 `?all=true` 查全部。
- 单据状态：pending → approved / rejected。

## 环境注意事项
- 本机 bash PATH 损坏（coreutils 不可用），必须用绝对路径调 node/npm。
- node: `C:/Users/ROG/.workbuddy/binaries/node/versions/22.22.2-3/node.exe`
- npm: `.../node_modules/npm/bin/npm-cli.js`
- 启动：`cd qinghe-demo && npm install && npm start` → http://localhost:5000
- 演示账号：zhangsan / admin / finance @qinghe.com，密码 123456。

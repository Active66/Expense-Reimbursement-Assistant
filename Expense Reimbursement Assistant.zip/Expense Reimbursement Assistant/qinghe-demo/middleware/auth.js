/**
 * 认证与授权中间件（沿用 madriq 项目的 verifyToken / restrictTo 设计）
 */
const jwt = require('jsonwebtoken');
const { store } = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'qinghe-demo-secret-key';

// 校验登录态，并把用户挂到 req.user
function verifyToken(req, res, next) {
  const header = req.header('Authorization') || '';
  const token = header.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({ message: '未登录，请先登录' });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = store.findById('users', decoded.id);
    if (!user) {
      return res.status(401).json({ message: '用户不存在' });
    }
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ message: '登录已过期，请重新登录' });
  }
}

// 角色白名单
function restrictTo(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: '无权限执行此操作' });
    }
    next();
  };
}

module.exports = { verifyToken, restrictTo, JWT_SECRET };

/**
 * 报销单据路由
 * - 提交报销（关联制度 + 上传材料）
 * - 员工查询本人单据状态（授权范围 = 本人）
 * - 财务专员（finance）查看全部单据并核对业务事实（通过 / 驳回）
 */
const express = require('express');
const multer = require('multer');
const path = require('path');
const { store, UPLOAD_DIR } = require('../db');
const { verifyToken, restrictTo } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1e6) + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = ['image/jpeg', 'image/png', 'application/pdf'].includes(file.mimetype);
    cb(ok ? null : new Error('仅支持 JPG / PNG / PDF 文件'), ok);
  }
});

// 提交报销（任何登录用户均可，作为申请人）
router.post('/submit', verifyToken, upload.array('materials', 5), (req, res) => {
  const { title, description, amount, category, date, policyId } = req.body || {};
  if (!title || !amount || !category || !date) {
    return res.status(400).json({ message: '请填写报销事由、金额、类别和日期' });
  }
  const policy = policyId ? store.findById('policies', policyId) : null;
  const files = (req.files || []).map((f) => '/uploads/' + f.filename);

  const expense = store.insert('expenses', {
    user: req.user.id,
    userName: req.user.name,
    department: req.user.department,
    title,
    description: description || '',
    amount: Number(amount),
    category,
    date,
    policyId: policy ? policy.id : null,
    policyTitle: policy ? policy.title : null,
    materials: files,
    status: 'pending'
  });
  res.status(201).json(expense);
});

// 查询本人单据状态（授权范围 = 本人，任何角色只能看自己的）
router.get('/my', verifyToken, (req, res) => {
  const list = store
    .find('expenses', (e) => e.user === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(list);
});

// 财务专员：查看全部单据（用于核对业务事实）
router.get('/all', verifyToken, restrictTo('finance'), (req, res) => {
  const list = store.find('expenses').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(list);
});

// 财务专员：核对业务事实（通过 / 驳回）
router.patch('/:id/review', verifyToken, restrictTo('finance'), (req, res) => {
  const { status, reviewComment } = req.body || {};
  if (!['approved', 'rejected'].includes(status)) {
    return res.status(400).json({ message: '无效的核对结果' });
  }
  const e = store.findById('expenses', req.params.id);
  if (!e) return res.status(404).json({ message: '单据不存在' });
  const updated = store.update('expenses', req.params.id, {
    status,
    reviewComment: reviewComment || '',
    reviewedBy: req.user.name,
    reviewedAt: new Date().toISOString()
  });
  res.json(updated);
});

module.exports = router;

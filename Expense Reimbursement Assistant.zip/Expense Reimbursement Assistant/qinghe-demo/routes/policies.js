/**
 * 制度路由
 * - 员工自助查询有效制度（支持关键词 + 类别筛选）
 * - 行政专员（admin_ops）维护制度：新增 / 编辑 / 失效
 */
const express = require('express');
const { store } = require('../db');
const { verifyToken, restrictTo } = require('../middleware/auth');

const router = express.Router();

// 查询制度列表（默认只返回"有效"制度；管理员可用 all=true 查看全部含失效）
router.get('/', verifyToken, (req, res) => {
  const { q, category, all } = req.query;
  let list = store.find('policies');
  if (all !== 'true') list = list.filter((p) => p.status === 'active');
  if (category) list = list.filter((p) => p.category === category);
  if (q) {
    const kw = String(q).toLowerCase();
    list = list.filter((p) =>
      `${p.title || ''} ${p.summary || ''} ${p.content || ''} ${p.category || ''}`
        .toLowerCase()
        .includes(kw)
    );
  }
  res.json(list);
});

// 制度详情
router.get('/:id', verifyToken, (req, res) => {
  const p = store.findById('policies', req.params.id);
  if (!p) return res.status(404).json({ message: '制度不存在' });
  res.json(p);
});

// 新增制度（行政专员）
router.post('/', verifyToken, restrictTo('admin_ops'), (req, res) => {
  const { title, category, summary, content, requiredMaterials, effectiveTo, status } = req.body || {};
  if (!title || !category || !content) {
    return res.status(400).json({ message: '请填写制度标题、类别和内容' });
  }
  const p = store.insert('policies', {
    title,
    category,
    summary: summary || '',
    content,
    requiredMaterials: Array.isArray(requiredMaterials) ? requiredMaterials : [],
    effectiveTo: effectiveTo || null,
    status: status === 'expired' ? 'expired' : 'active',
    version: 1,
    maintainedBy: req.user.name
  });
  res.status(201).json(p);
});

// 编辑制度（行政专员）
router.put('/:id', verifyToken, restrictTo('admin_ops'), (req, res) => {
  const p = store.findById('policies', req.params.id);
  if (!p) return res.status(404).json({ message: '制度不存在' });
  const { title, category, summary, content, requiredMaterials, effectiveTo, status } = req.body || {};
  const updated = store.update('policies', req.params.id, {
    title: title ?? p.title,
    category: category ?? p.category,
    summary: summary ?? p.summary,
    content: content ?? p.content,
    requiredMaterials: requiredMaterials ?? p.requiredMaterials,
    effectiveTo: effectiveTo ?? p.effectiveTo,
    status: status ?? p.status,
    version: (p.version || 1) + 1,
    maintainedBy: req.user.name
  });
  res.json(updated);
});

// 制度失效（行政专员）
router.patch('/:id/expire', verifyToken, restrictTo('admin_ops'), (req, res) => {
  const p = store.findById('policies', req.params.id);
  if (!p) return res.status(404).json({ message: '制度不存在' });
  const updated = store.update('policies', req.params.id, { status: 'expired', maintainedBy: req.user.name });
  res.json(updated);
});

module.exports = router;

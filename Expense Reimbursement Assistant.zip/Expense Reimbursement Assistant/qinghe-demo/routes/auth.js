/**
 * 认证路由：注册 / 登录 / 当前用户
 */
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { store } = require('../db');
const { verifyToken, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

function signToken(user) {
  return jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
}

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    department: user.department
  };
}

// 注册（demo 中开放注册，默认角色为员工）
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, department } = req.body || {};
    if (!name || !email || !password || !department) {
      return res.status(400).json({ message: '请填写姓名、邮箱、密码和部门' });
    }
    if (store.findOne('users', (u) => u.email === email)) {
      return res.status(400).json({ message: '该邮箱已注册' });
    }
    const user = store.insert('users', {
      name,
      email,
      password: await bcrypt.hash(password, 10),
      department,
      role: 'employee' // 行政/财务账号由种子数据预设，注册仅开放员工
    });
    return res.status(201).json({ token: signToken(user), user: publicUser(user) });
  } catch (e) {
    return res.status(500).json({ message: '服务器错误' });
  }
});

// 登录
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const user = store.findOne('users', (u) => u.email === email);
    if (!user || !(await bcrypt.compare(password || '', user.password))) {
      return res.status(401).json({ message: '邮箱或密码错误' });
    }
    return res.json({ token: signToken(user), user: publicUser(user) });
  } catch (e) {
    return res.status(500).json({ message: '服务器错误' });
  }
});

// 当前登录用户
router.get('/me', verifyToken, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

module.exports = router;

# 青禾报销助手（Demo）

一个轻量级的报销流程智能体 Demo：员工自助查询有效制度 → 按制度要求提交报销材料 → 进入报销流程 → 经授权查询本人单据状态；制度由行政专员维护，业务事实由财务专员核对。

## 二次开发来源

本项目基于 GitHub 开源项目 [madriq/Expense-Reimbursement-app](https://github.com/madriq/Expense-Reimbursement-app)（MIT 协议）二次开发，复用并改造了其核心设计：

| 维度 | 原项目 madriq | 青禾报销助手 |
| --- | --- | --- |
| 认证中间件 | `verifyToken` / `restrictTo` / `checkOwnership` | ✅ 沿用设计 |
| 数据模型 | User / Expense / AuditLog（Mongoose） | User / Policy / Expense（新增「制度」模型） |
| 角色 | employee / manager / admin | employee / admin_ops / finance |
| 数据库 | MongoDB + Mongoose | 轻量 JSON 文件存储（零依赖，开箱即用） |
| 前端 | React + Material-UI | 原生 HTML/CSS/JS（零构建） |
| 业务核心 | 通用报销提交 + 审批 | 查制度 → 提交 → 报销流程 → 查单据状态 |

> 调研结论：另一个候选 [Abhinavhaldiya/FinPilot](https://github.com/Abhinavhaldiya/FinPilot) 的 README 虽号称企业级，但后端实际为占位符空壳（仅 User 模型），不具备二次开发基础，故弃用。原始 madriq 代码保留在 `../madriq-base/` 供参考。

## 核心流程

```
员工自助查有效制度 → 查看制度要求与所需材料 → 提交报销（关联制度 + 上传材料）
      → 进入报销流程（待核对） → 财务专员核对业务事实（通过/驳回）
      → 员工经授权查询本人单据状态
```

## 角色与权限

| 角色 | 标识 | 职责 |
| --- | --- | --- |
| 员工 | `employee` | 查制度、提交报销、查询本人单据状态 |
| 行政专员 | `admin_ops` | 维护制度（新增 / 编辑 / 失效） |
| 财务专员 | `finance` | 查看全部单据、核对业务事实（通过 / 驳回） |

## 快速开始

```bash
# 1. 安装依赖
npm install

# 2. 启动（首次启动自动初始化演示数据）
npm start

# 3. 打开浏览器访问
#    http://localhost:5000
```

演示账号（密码均为 `123456`）：

| 账号 | 角色 | 姓名 |
| --- | --- | --- |
| zhangsan@qinghe.com | 员工 | 张三 |
| admin@qinghe.com | 行政专员 | 李四 |
| finance@qinghe.com | 财务专员 | 王五 |

## 目录结构

```
qinghe-demo/
├── server.js            # 主入口（Express + 静态托管）
├── db.js                # JSON 存储层 + 种子数据
├── middleware/auth.js   # 认证授权中间件
├── routes/
│   ├── auth.js          # 注册 / 登录 / 当前用户
│   ├── policies.js      # 制度查询 + 行政专员维护
│   └── expenses.js      # 提交报销 / 查本人单据 / 财务核对
├── public/
│   ├── index.html       # 单页应用
│   ├── css/style.css    # 样式
│   └── js/app.js        # 前端逻辑（按角色渲染视图）
├── data/                # 运行时生成的 JSON 数据（自动创建）
└── uploads/             # 上传的报销材料（自动创建）
```

## API 一览

| 方法 | 路径 | 权限 | 说明 |
| --- | --- | --- | --- |
| POST | /api/auth/register | 公开 | 注册（默认员工） |
| POST | /api/auth/login | 公开 | 登录 |
| GET | /api/auth/me | 登录 | 当前用户 |
| GET | /api/policies | 登录 | 查询制度（默认仅有效，支持 `q`/`category`/`all`） |
| GET | /api/policies/:id | 登录 | 制度详情 |
| POST | /api/policies | 行政专员 | 新增制度 |
| PUT | /api/policies/:id | 行政专员 | 编辑制度 |
| PATCH | /api/policies/:id/expire | 行政专员 | 制度失效 |
| POST | /api/expenses/submit | 登录 | 提交报销（关联制度 + 上传材料） |
| GET | /api/expenses/my | 登录 | 查询本人单据状态 |
| GET | /api/expenses/all | 财务专员 | 查看全部单据 |
| PATCH | /api/expenses/:id/review | 财务专员 | 核对业务事实（通过/驳回） |

## 后续扩展方向

- 数据层可无缝替换回 MongoDB（仅需改写 `db.js` 的 store 实现）
- 增加多级审批（部门负责人 → 财务）与金额阈值
- 单据状态接入消息/邮件通知
- 制度版本历史与到期自动失效

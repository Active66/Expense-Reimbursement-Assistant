/**
 * 轻量 JSON 文件存储层
 * 替代原 madriq 项目中的 MongoDB/Mongoose，让 demo 零数据库依赖、开箱即用。
 * 对外暴露统一的 store 接口，未来如需切换回 MongoDB，仅需替换本文件。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(__dirname, 'uploads');

function uid() {
  return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');
}

function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

function fileFor(name) {
  return path.join(DATA_DIR, name + '.json');
}

function read(name) {
  ensureDirs();
  const f = fileFor(name);
  if (!fs.existsSync(f)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(f, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

function write(name, data) {
  ensureDirs();
  fs.writeFileSync(fileFor(name), JSON.stringify(data, null, 2), 'utf8');
}

const store = {
  find: (name, predicate) => read(name).filter(predicate || (() => true)),
  findOne: (name, predicate) => read(name).find(predicate),
  findById: (name, id) => read(name).find((x) => x.id === id),
  insert: (name, doc) => {
    const all = read(name);
    const item = { id: uid(), createdAt: new Date().toISOString(), ...doc };
    all.push(item);
    write(name, all);
    return item;
  },
  update: (name, id, patch) => {
    const all = read(name);
    const idx = all.findIndex((x) => x.id === id);
    if (idx === -1) return null;
    all[idx] = { ...all[idx], ...patch, updatedAt: new Date().toISOString() };
    write(name, all);
    return all[idx];
  },
  remove: (name, id) => {
    const all = read(name);
    const idx = all.findIndex((x) => x.id === id);
    if (idx === -1) return false;
    all.splice(idx, 1);
    write(name, all);
    return true;
  }
};

/**
 * 首次启动时自动写入种子数据：3 个演示账号 + 示例制度。
 * 密码统一为 123456（演示用）。
 */
function ensureSeed() {
  if (store.find('users').length > 0) return;

  const users = [
    { name: '张三', email: 'zhangsan@qinghe.com', password: bcrypt.hashSync('123456', 10), role: 'employee', department: '市场部' },
    { name: '李四', email: 'admin@qinghe.com', password: bcrypt.hashSync('123456', 10), role: 'admin_ops', department: '行政部' },
    { name: '王五', email: 'finance@qinghe.com', password: bcrypt.hashSync('123456', 10), role: 'finance', department: '财务部' }
  ];
  users.forEach((u) => store.insert('users', u));

  const policies = [
    {
      title: '差旅费报销制度',
      category: '差旅费',
      summary: '员工因公出差产生的交通、住宿及市内交通费用的报销标准与流程。',
      content: '一、报销范围：因公出差产生的交通费、住宿费、市内交通费。\n二、标准：高铁二等座或经济舱；住宿上限 500 元/晚；市内交通据实报销。\n三、流程：出差前提交《出差审批单》，出差结束后 15 个工作日内提交报销。\n四、超标准部分需提前申请并获批。',
      requiredMaterials: ['出差审批单', '交通票据（车票/机票行程单）', '住宿发票', '住宿水单'],
      version: 1,
      status: 'active',
      effectiveTo: '2026-12-31',
      maintainedBy: '李四'
    },
    {
      title: '办公用品采购报销制度',
      category: '办公用品',
      summary: '办公用品的采购申请、金额上限与报销要求。',
      content: '一、单次采购金额 500 元以内可由部门自行采购。\n二、500 元以上需提前提交《采购申请单》并经行政部审批。\n三、报销时需附发票与验收单，发票抬头须为公司全称。',
      requiredMaterials: ['采购申请单', '购物发票', '验收单'],
      version: 1,
      status: 'active',
      effectiveTo: null,
      maintainedBy: '李四'
    },
    {
      title: '业务招待费报销制度',
      category: '业务招待',
      summary: '业务招待费的审批权限、标准与报销材料要求。',
      content: '一、招待前需提交《招待申请单》并获批。\n二、单人单次招待标准不超过 200 元。\n三、报销需提供餐饮发票与参与人员名单。',
      requiredMaterials: ['招待申请单', '餐饮发票', '参与人员名单'],
      version: 1,
      status: 'active',
      effectiveTo: null,
      maintainedBy: '李四'
    },
    {
      title: '差旅费报销制度（旧版）',
      category: '差旅费',
      summary: '已被新版制度替代，仅供参考，不再执行。',
      content: '旧版差旅报销标准，已于 2025-12-31 废止。',
      requiredMaterials: ['出差审批单', '交通票据'],
      version: 1,
      status: 'expired',
      effectiveTo: '2025-12-31',
      maintainedBy: '李四'
    }
  ];
  policies.forEach((p) => store.insert('policies', p));

  console.log('已初始化演示数据（3 个账号 + 4 条示例制度）。');
}

module.exports = { store, uid, DATA_DIR, UPLOAD_DIR, ensureSeed };

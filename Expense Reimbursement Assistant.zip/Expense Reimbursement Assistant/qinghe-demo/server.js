/**
 * 青禾报销助手 demo 主入口
 * 启动：node server.js   （访问 http://localhost:5000）
 */
const express = require('express');
const path = require('path');
const cors = require('cors');
const { ensureSeed } = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;

// 初始化演示数据（首次启动）
ensureSeed();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 静态资源：前端页面 + 上传材料
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API 路由
app.use('/api/auth', require('./routes/auth'));
app.use('/api/policies', require('./routes/policies'));
app.use('/api/expenses', require('./routes/expenses'));

app.get('/api/health', (req, res) => res.json({ ok: true, name: '青禾报销助手' }));

// 统一错误处理
app.use((err, req, res, next) => {
  res.status(err.status || 500).json({ message: err.message || '服务器错误' });
});

app.listen(PORT, () => {
  console.log('============================================');
  console.log('  青禾报销助手 demo 已启动');
  console.log(`  访问地址: http://localhost:${PORT}`);
  console.log('  演示账号（密码均为 123456）:');
  console.log('    员工:   zhangsan@qinghe.com');
  console.log('    行政专员: admin@qinghe.com');
  console.log('    财务专员: finance@qinghe.com');
  console.log('============================================');
});

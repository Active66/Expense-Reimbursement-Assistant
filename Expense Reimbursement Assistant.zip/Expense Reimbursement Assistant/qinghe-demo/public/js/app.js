/* ===== 青禾报销助手 demo 前端逻辑 ===== */

const API = '/api';
const ROLE_LABEL = { employee: '员工', admin_ops: '行政专员', finance: '财务专员' };
const STATUS_LABEL = { pending: '待核对', approved: '已通过', rejected: '已驳回' };
const CATEGORIES = ['差旅费', '办公用品', '业务招待', '其他'];

let token = localStorage.getItem('token') || '';
let user = JSON.parse(localStorage.getItem('user') || 'null');
let currentView = '';

/* ---------- 通用 ---------- */
function $(sel) { return document.querySelector(sel); }

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (token) headers['Authorization'] = 'Bearer ' + token;
  if (options.body && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(options.body);
  }
  const res = await fetch(API + path, { ...options, headers });
  let data = {};
  try { data = await res.json(); } catch (e) { /* ignore */ }
  if (!res.ok) {
    const err = new Error(data.message || '请求失败');
    err.status = res.status;
    throw err;
  }
  return data;
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtMoney(n) { return '¥' + Number(n || 0).toFixed(2); }
function fmtDate(s) { return s ? String(s).slice(0, 10) : '-'; }

function openModal(html) {
  $('#modal-box').innerHTML = html;
  $('#modal').classList.remove('hidden');
}
function closeModal() { $('#modal').classList.add('hidden'); }

function statusTag(status) {
  const label = STATUS_LABEL[status] || status;
  return `<span class="tag tag-${status}">${label}</span>`;
}

/* ---------- 认证 ---------- */
function bindAuth() {
  const tabs = document.querySelectorAll('#auth-tabs .tab');
  tabs.forEach((t) => t.addEventListener('click', () => {
    tabs.forEach((x) => x.classList.remove('active'));
    t.classList.add('active');
    const isLogin = t.dataset.tab === 'login';
    $('#login-form').classList.toggle('hidden', !isLogin);
    $('#register-form').classList.toggle('hidden', isLogin);
  }));

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#login-msg').textContent = '';
    try {
      const email = $('#login-email').value.trim();
      const password = $('#login-password').value;
      const data = await api('/auth/login', { method: 'POST', body: { email, password } });
      onLogin(data);
    } catch (err) { $('#login-msg').textContent = err.message; }
  });

  $('#register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#reg-msg').textContent = '';
    try {
      const body = {
        name: $('#reg-name').value.trim(),
        email: $('#reg-email').value.trim(),
        department: $('#reg-department').value.trim(),
        password: $('#reg-password').value
      };
      const data = await api('/auth/register', { method: 'POST', body });
      onLogin(data);
    } catch (err) { $('#reg-msg').textContent = err.message; }
  });

  document.querySelectorAll('.chip').forEach((c) => c.addEventListener('click', () => {
    $('#login-email').value = c.dataset.email;
    $('#login-password').value = '123456';
  }));
}

function onLogin(data) {
  token = data.token;
  user = data.user;
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
  showApp();
}

function logout() {
  token = ''; user = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  showAuth();
}

function showAuth() {
  $('#app-view').classList.add('hidden');
  $('#auth-view').classList.remove('hidden');
}

function showApp() {
  $('#auth-view').classList.add('hidden');
  $('#app-view').classList.remove('hidden');
  $('#user-name').textContent = user.name;
  $('#role-badge').textContent = ROLE_LABEL[user.role] || user.role;
  $('#role-badge').dataset.role = user.role;
  renderNav();
  go(defaultView());
}

function defaultView() {
  if (user.role === 'admin_ops') return 'policy-admin';
  if (user.role === 'finance') return 'finance-review';
  return 'policies';
}

/* ---------- 导航 ---------- */
const NAV_MAP = {
  employee: [
    { id: 'policies', label: '查制度' },
    { id: 'submit', label: '提交报销' },
    { id: 'my-expenses', label: '我的单据' }
  ],
  admin_ops: [
    { id: 'policies', label: '查制度' },
    { id: 'policy-admin', label: '制度管理' }
  ],
  finance: [
    { id: 'policies', label: '查制度' },
    { id: 'finance-review', label: '单据核对' }
  ]
};

function renderNav() {
  const items = NAV_MAP[user.role] || NAV_MAP.employee;
  $('#nav').innerHTML = items.map((it) =>
    `<button class="nav-item" data-view="${it.id}">${it.label}</button>`
  ).join('');
  document.querySelectorAll('.nav-item').forEach((b) => b.addEventListener('click', () => go(b.dataset.view)));
}

function go(view) {
  currentView = view;
  document.querySelectorAll('.nav-item').forEach((b) =>
    b.classList.toggle('active', b.dataset.view === view)
  );
  const el = $('#content');
  el.innerHTML = '<div class="empty"><div class="icon">⏳</div>加载中…</div>';
  const renderers = {
    'policies': renderPolicies,
    'submit': renderSubmit,
    'my-expenses': renderMyExpenses,
    'policy-admin': renderPolicyAdmin,
    'finance-review': renderFinance
  };
  (renderers[view] || renderPolicies)();
}

/* ---------- 查制度（员工自助） ---------- */
async function renderPolicies() {
  const content = $('#content');
  content.innerHTML = `
    <h2 class="section-title">制度查询</h2>
    <p class="section-desc">自助查询当前有效的报销制度，了解标准与所需材料</p>
    <div class="toolbar">
      <input type="text" id="policy-search" placeholder="搜索制度关键词，如：差旅、招待…" />
      <select id="policy-category">
        <option value="">全部分类</option>
        ${CATEGORIES.map((c) => `<option value="${c}">${c}</option>`).join('')}
      </select>
      <button class="btn btn-primary" id="policy-search-btn">查询</button>
    </div>
    <div class="grid" id="policy-list"></div>
  `;

  const load = async () => {
    const q = $('#policy-search').value.trim();
    const category = $('#policy-category').value;
    const query = new URLSearchParams();
    if (q) query.set('q', q);
    if (category) query.set('category', category);
    const list = await api('/policies?' + query.toString());
    renderPolicyList(list);
  };

  $('#policy-search-btn').addEventListener('click', load);
  $('#policy-search').addEventListener('keydown', (e) => { if (e.key === 'Enter') load(); });
  $('#policy-category').addEventListener('change', load);
  load();
}

function renderPolicyList(list) {
  const box = $('#policy-list');
  if (!list.length) {
    box.innerHTML = '<div class="empty"><div class="icon">📄</div>未找到相关制度</div>';
    return;
  }
  box.innerHTML = list.map((p) => `
    <div class="card">
      <span class="cat">${esc(p.category)}</span>
      <h3>${esc(p.title)}</h3>
      <p class="summary">${esc(p.summary || '')}</p>
      <div class="meta">
        <span>版本 v${p.version || 1}</span>
        <span>维护：${esc(p.maintainedBy || '-')}</span>
        ${p.effectiveTo ? `<span>有效期至 ${fmtDate(p.effectiveTo)}</span>` : '<span>长期有效</span>'}
      </div>
      <div>
        <button class="btn btn-primary btn-sm" onclick="viewPolicy('${p.id}')">查看详情</button>
        ${user.role === 'employee' ? `<button class="btn btn-ghost btn-sm" onclick="submitWithPolicy('${p.id}')">按此制度报销</button>` : ''}
      </div>
    </div>
  `).join('');
}

async function viewPolicy(id) {
  const p = await api('/policies/' + id);
  openModal(`
    <button class="modal-close" onclick="closeModal()">×</button>
    <h2>${esc(p.title)} <span class="tag tag-${p.status}">${p.status === 'active' ? '有效' : '已失效'}</span></h2>
    <div class="kv">
      <span class="kv-item"><b>分类：</b>${esc(p.category)}</span>
      <span class="kv-item"><b>版本：</b>v${p.version || 1}</span>
      <span class="kv-item"><b>维护人：</b>${esc(p.maintainedBy || '-')}</span>
      <span class="kv-item"><b>有效期：</b>${p.effectiveTo ? '至 ' + fmtDate(p.effectiveTo) : '长期有效'}</span>
    </div>
    <p class="muted" style="margin-bottom:8px;">制度内容</p>
    <div class="policy-content">${esc(p.content || '')}</div>
    <p class="muted" style="margin:14px 0 8px;">报销所需材料</p>
    ${(p.requiredMaterials && p.requiredMaterials.length)
      ? `<ul class="material-list">${p.requiredMaterials.map((m) => `<li>${esc(m)}</li>`).join('')}</ul>`
      : '<p class="muted">无特别材料要求</p>'}
    ${user.role === 'employee' ? `<button class="btn btn-primary" style="margin-top:16px;" onclick="closeModal();go('submit')">按此制度提交报销</button>` : ''}
  `);
}

function submitWithPolicy(id) {
  go('submit');
  // 延迟设置，等待 submit 视图渲染
  setTimeout(() => { const sel = $('#expense-policy'); if (sel) sel.value = id; }, 50);
}

/* ---------- 提交报销 ---------- */
async function renderSubmit() {
  const content = $('#content');
  content.innerHTML = `
    <h2 class="section-title">提交报销</h2>
    <p class="section-desc">根据所选制度的要求准备并上传材料</p>
    <div class="form-panel">
      <div class="row">
        <div class="field">
          <label>关联制度<span class="req">*</span></label>
          <select id="expense-policy"><option value="">请选择制度</option></select>
        </div>
        <div class="field">
          <label>报销类别<span class="req">*</span></label>
          <select id="expense-category">
            <option value="">请选择类别</option>
            ${CATEGORIES.map((c) => `<option value="${c}">${c}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="field">
        <label>报销事由<span class="req">*</span></label>
        <input type="text" id="expense-title" placeholder="如：上海出差高铁及住宿费" />
      </div>
      <div class="row">
        <div class="field">
          <label>金额（元）<span class="req">*</span></label>
          <input type="number" id="expense-amount" min="0.01" step="0.01" placeholder="0.00" />
        </div>
        <div class="field">
          <label>费用发生日期<span class="req">*</span></label>
          <input type="date" id="expense-date" />
        </div>
      </div>
      <div class="field">
        <label>说明</label>
        <textarea id="expense-desc" placeholder="补充说明（可选）"></textarea>
      </div>
      <div class="field">
        <label>上传材料（发票 / 审批单等，最多 5 个文件）</label>
        <input type="file" id="expense-files" multiple accept=".jpg,.jpeg,.png,.pdf" />
        <div class="file-hint">支持 JPG / PNG / PDF，单个不超过 5MB</div>
      </div>
      <div id="policy-requirement" class="muted" style="margin-bottom:14px;"></div>
      <button class="btn btn-primary" id="submit-btn">提交报销申请</button>
      <span class="form-msg" id="submit-msg"></span>
    </div>
  `;

  // 加载有效制度
  const policies = await api('/policies');
  $('#expense-policy').innerHTML = '<option value="">请选择制度</option>' +
    policies.map((p) => `<option value="${p.id}">${esc(p.title)}</option>`).join('');

  const refreshRequirement = () => {
    const pid = $('#expense-policy').value;
    const p = policies.find((x) => x.id === pid);
    if (p) {
      $('#expense-policy').closest('.field').parentElement;
      $('#policy-requirement').innerHTML =
        (p.requiredMaterials && p.requiredMaterials.length)
          ? '📋 该制度要求材料：' + p.requiredMaterials.map((m) => esc(m)).join('、')
          : '';
      // 自动带出类别
      $('#expense-category').value = p.category;
    } else {
      $('#policy-requirement').innerHTML = '';
    }
  };
  $('#expense-policy').addEventListener('change', refreshRequirement);

  $('#submit-btn').addEventListener('click', async () => {
    $('#submit-msg').textContent = '';
    const title = $('#expense-title').value.trim();
    const amount = $('#expense-amount').value;
    const date = $('#expense-date').value;
    const category = $('#expense-category').value;
    const policyId = $('#expense-policy').value;
    const desc = $('#expense-desc').value.trim();
    const files = $('#expense-files').files;

    if (!title || !amount || !date || !category) {
      $('#submit-msg').textContent = '请填写完整的事由、金额、类别和日期';
      return;
    }

    const fd = new FormData();
    fd.append('title', title);
    fd.append('amount', amount);
    fd.append('date', date);
    fd.append('category', category);
    fd.append('description', desc);
    if (policyId) fd.append('policyId', policyId);
    for (const f of files) fd.append('materials', f);

    try {
      await api('/expenses/submit', { method: 'POST', body: fd });
      $('#submit-msg').textContent = '';
      alert('提交成功，已进入报销流程，等待财务专员核对。');
      go('my-expenses');
    } catch (err) {
      $('#submit-msg').textContent = err.message;
    }
  });
}

/* ---------- 我的单据（授权查询本人状态） ---------- */
async function renderMyExpenses() {
  const content = $('#content');
  content.innerHTML = `
    <h2 class="section-title">我的单据</h2>
    <p class="section-desc">查询本人报销单据的处理状态</p>
    <div id="my-list"></div>
  `;
  const list = await api('/expenses/my');
  const box = $('#my-list');
  if (!list.length) {
    box.innerHTML = '<div class="empty"><div class="icon">📭</div>暂无报销单据</div>';
    return;
  }
  box.innerHTML = `<table class="table">
    <thead><tr><th>报销事由</th><th>类别</th><th>金额</th><th>状态</th><th>提交时间</th><th>操作</th></tr></thead>
    <tbody>${list.map((e) => `
      <tr>
        <td>${esc(e.title)}</td>
        <td>${esc(e.category)}</td>
        <td>${fmtMoney(e.amount)}</td>
        <td>${statusTag(e.status)}</td>
        <td>${fmtDate(e.createdAt)}</td>
        <td><button class="btn btn-ghost btn-sm" onclick="viewExpense('${e.id}')">详情</button></td>
      </tr>`).join('')}
    </tbody></table>`;
}

async function viewExpense(id) {
  const list = await api('/expenses/my');
  const e = list.find((x) => x.id === id);
  if (!e) return;
  openModal(`
    <button class="modal-close" onclick="closeModal()">×</button>
    <h2>单据详情 ${statusTag(e.status)}</h2>
    <div class="kv">
      <span class="kv-item"><b>事由：</b>${esc(e.title)}</span>
      <span class="kv-item"><b>金额：</b>${fmtMoney(e.amount)}</span>
      <span class="kv-item"><b>类别：</b>${esc(e.category)}</span>
      <span class="kv-item"><b>发生日期：</b>${fmtDate(e.date)}</span>
      <span class="kv-item"><b>关联制度：</b>${esc(e.policyTitle || '未关联')}</span>
      <span class="kv-item"><b>提交时间：</b>${fmtDate(e.createdAt)}</span>
    </div>
    ${e.description ? `<p class="muted" style="margin-bottom:8px;">${esc(e.description)}</p>` : ''}
    ${e.materials && e.materials.length ? `
      <p class="muted" style="margin-bottom:8px;">上传材料</p>
      <ul class="material-list">${e.materials.map((m) => `<li><a href="${esc(m)}" target="_blank">${esc(m.split('/').pop())}</a></li>`).join('')}</ul>` : ''}
    ${e.status !== 'pending' ? `
      <div class="kv" style="margin-top:12px;">
        <span class="kv-item"><b>核对人：</b>${esc(e.reviewedBy || '-')}</span>
        <span class="kv-item"><b>核对时间：</b>${fmtDate(e.reviewedAt)}</span>
      </div>
      ${e.reviewComment ? `<p class="muted">核对意见：${esc(e.reviewComment)}</p>` : ''}` : ''}
  `);
}

/* ---------- 制度管理（行政专员） ---------- */
async function renderPolicyAdmin() {
  const content = $('#content');
  content.innerHTML = `
    <h2 class="section-title">制度管理</h2>
    <p class="section-desc">行政专员维护报销制度（新增 / 编辑 / 失效）</p>
    <div class="toolbar">
      <button class="btn btn-primary" onclick="editPolicy()">＋ 新增制度</button>
    </div>
    <div id="policy-admin-list"></div>
  `;
  await loadPolicyAdminList();
}

async function loadPolicyAdminList() {
  const list = await api('/policies?all=true');
  const box = $('#policy-admin-list');
  box.innerHTML = `<table class="table">
    <thead><tr><th>制度标题</th><th>类别</th><th>版本</th><th>状态</th><th>维护人</th><th>操作</th></tr></thead>
    <tbody>${list.map((p) => `
      <tr>
        <td>${esc(p.title)}</td>
        <td>${esc(p.category)}</td>
        <td>v${p.version || 1}</td>
        <td><span class="tag tag-${p.status}">${p.status === 'active' ? '有效' : '已失效'}</span></td>
        <td>${esc(p.maintainedBy || '-')}</td>
        <td class="actions">
          <button class="btn btn-ghost btn-sm" onclick="editPolicy('${p.id}')">编辑</button>
          ${p.status === 'active'
            ? `<button class="btn btn-ghost btn-sm" onclick="expirePolicy('${p.id}')">失效</button>`
            : ''}
        </td>
      </tr>`).join('')}
    </tbody></table>`;
}

function policyForm(p) {
  const isNew = !p;
  openModal(`
    <button class="modal-close" onclick="closeModal()">×</button>
    <h2>${isNew ? '新增制度' : '编辑制度'}</h2>
    <div class="field"><label>标题<span class="req">*</span></label><input id="pf-title" value="${esc(p?.title || '')}" /></div>
    <div class="field"><label>类别<span class="req">*</span></label>
      <select id="pf-category">${CATEGORIES.map((c) => `<option value="${c}" ${p?.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
    </div>
    <div class="field"><label>摘要</label><input id="pf-summary" value="${esc(p?.summary || '')}" /></div>
    <div class="field"><label>制度内容<span class="req">*</span></label><textarea id="pf-content">${esc(p?.content || '')}</textarea></div>
    <div class="field"><label>所需材料（每行一条）</label><textarea id="pf-materials">${esc((p?.requiredMaterials || []).join('\n'))}</textarea></div>
    <div class="field"><label>有效期至（留空为长期有效）</label><input type="date" id="pf-effectiveTo" value="${p?.effectiveTo || ''}" /></div>
    <button class="btn btn-primary" id="pf-save">保存</button>
    <span class="form-msg" id="pf-msg"></span>
  `);
  $('#pf-save').addEventListener('click', async () => {
    $('#pf-msg').textContent = '';
    const body = {
      title: $('#pf-title').value.trim(),
      category: $('#pf-category').value,
      summary: $('#pf-summary').value.trim(),
      content: $('#pf-content').value.trim(),
      requiredMaterials: $('#pf-materials').value.split('\n').map((s) => s.trim()).filter(Boolean),
      effectiveTo: $('#pf-effectiveTo').value || null,
      status: 'active'
    };
    if (!body.title || !body.content) { $('#pf-msg').textContent = '请填写标题和内容'; return; }
    try {
      if (isNew) await api('/policies', { method: 'POST', body });
      else await api('/policies/' + p.id, { method: 'PUT', body });
      closeModal();
      await loadPolicyAdminList();
    } catch (err) { $('#pf-msg').textContent = err.message; }
  });
}

function editPolicy(id) {
  api('/policies/' + id).then((p) => policyForm(p)).catch((e) => alert(e.message));
}

async function expirePolicy(id) {
  if (!confirm('确定将该制度设为失效吗？')) return;
  await api('/policies/' + id + '/expire', { method: 'PATCH' });
  await loadPolicyAdminList();
}

/* ---------- 单据核对（财务专员） ---------- */
async function renderFinance() {
  const content = $('#content');
  content.innerHTML = `
    <h2 class="section-title">单据核对</h2>
    <p class="section-desc">财务专员核对业务事实，通过或驳回报销单据</p>
    <div id="finance-list"></div>
  `;
  await loadFinanceList();
}

async function loadFinanceList() {
  const list = await api('/expenses/all');
  const box = $('#finance-list');
  if (!list.length) {
    box.innerHTML = '<div class="empty"><div class="icon">📭</div>暂无报销单据</div>';
    return;
  }
  const pending = list.filter((e) => e.status === 'pending');
  box.innerHTML = `
    ${pending.length ? `<p class="muted" style="margin-bottom:8px;">待核对 ${pending.length} 条</p>` : ''}
    <table class="table">
      <thead><tr><th>申请人</th><th>事由</th><th>类别</th><th>金额</th><th>状态</th><th>提交时间</th><th>操作</th></tr></thead>
      <tbody>${list.map((e) => `
        <tr>
          <td>${esc(e.userName)}<br><span class="muted">${esc(e.department || '')}</span></td>
          <td>${esc(e.title)}</td>
          <td>${esc(e.category)}</td>
          <td>${fmtMoney(e.amount)}</td>
          <td>${statusTag(e.status)}</td>
          <td>${fmtDate(e.createdAt)}</td>
          <td class="actions">
            <button class="btn btn-ghost btn-sm" onclick="viewExpenseFinance('${e.id}')">详情</button>
            ${e.status === 'pending' ? `
              <button class="btn btn-primary btn-sm" onclick="reviewExpense('${e.id}','approved')">通过</button>
              <button class="btn btn-danger btn-sm" onclick="reviewExpense('${e.id}','rejected')">驳回</button>` : ''}
          </td>
        </tr>`).join('')}
      </tbody></table>`;
}

async function viewExpenseFinance(id) {
  const list = await api('/expenses/all');
  const e = list.find((x) => x.id === id);
  if (!e) return;
  openModal(`
    <button class="modal-close" onclick="closeModal()">×</button>
    <h2>单据详情 ${statusTag(e.status)}</h2>
    <div class="kv">
      <span class="kv-item"><b>申请人：</b>${esc(e.userName)}（${esc(e.department || '-')}）</span>
      <span class="kv-item"><b>事由：</b>${esc(e.title)}</span>
      <span class="kv-item"><b>金额：</b>${fmtMoney(e.amount)}</span>
      <span class="kv-item"><b>类别：</b>${esc(e.category)}</span>
      <span class="kv-item"><b>发生日期：</b>${fmtDate(e.date)}</span>
      <span class="kv-item"><b>关联制度：</b>${esc(e.policyTitle || '未关联')}</span>
    </div>
    ${e.description ? `<p class="muted">${esc(e.description)}</p>` : ''}
    ${e.materials && e.materials.length ? `
      <p class="muted" style="margin:8px 0;">上传材料</p>
      <ul class="material-list">${e.materials.map((m) => `<li><a href="${esc(m)}" target="_blank">${esc(m.split('/').pop())}</a></li>`).join('')}</ul>` : ''}
  `);
}

async function reviewExpense(id, status) {
  let comment = '';
  if (status === 'rejected') {
    comment = prompt('请输入驳回原因（业务事实核对意见）', '');
    if (comment === null) return;
  } else {
    if (!confirm('确认通过该报销单据？')) return;
  }
  await api('/expenses/' + id + '/review', { method: 'PATCH', body: { status, reviewComment: comment } });
  await loadFinanceList();
}

/* ---------- 全局暴露给内联 onclick ---------- */
window.viewPolicy = viewPolicy;
window.viewExpense = viewExpense;
window.viewExpenseFinance = viewExpenseFinance;
window.submitWithPolicy = submitWithPolicy;
window.editPolicy = editPolicy;
window.expirePolicy = expirePolicy;
window.reviewExpense = reviewExpense;
window.closeModal = closeModal;

/* ---------- 启动 ---------- */
$('#logout-btn').addEventListener('click', logout);
$('#modal-mask').addEventListener('click', closeModal);
bindAuth();

if (token && user) {
  // 校验 token 有效性
  api('/auth/me').then(() => showApp()).catch(() => { logout(); });
} else {
  showAuth();
}
